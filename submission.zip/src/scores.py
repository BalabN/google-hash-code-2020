def score_libs1(book_scores, libraries):
    return libraries
